"""
Group B1 - AI-based 10-second Emergency Behaviour Detection Module

Install:  pip install numpy pandas scikit-learn xgboost requests joblib
Run:      python b1_emergency_detection.py            (polls the camera team's URL)
          python b1_emergency_detection.py <url>      (poll a different URL, e.g. a new ngrok link)
          python b1_emergency_detection.py demo       (no camera needed: runs a simulated patient instead)

WHAT THIS PROGRAM DOES (big picture)
    Camera team's URL (latest 10-second window, polled every few seconds) -> XGBoost
    -> NORMAL / ABNORMAL -> severity (LOW / MEDIUM / HIGH) -> JSON record -> sent to Group B2

FILE LAYOUT
    SECTION 1  : Imports and global settings
    SECTION 2  : B1.1 Dataset creation (simulated behaviour data)
    SECTION 3  : B1.2 10-second window processing / feature extraction
    SECTION 4  : B1.4 Severity classification (rule based)
    SECTION 5  : B1.3 Model evaluation helper
    SECTION 6  : INTEGRATION (detector class, sending to B2, polling the camera team's URL)
    SECTION 7  : main() - trains the models, saves them, then starts polling
"""

# =====================================================================================
# SECTION 1: IMPORTS AND GLOBAL SETTINGS
# =====================================================================================
import os                        # to check whether the log file already exists
import sys                       # to read an optional URL from the command line
import time                      # to wait between polls
import json                      # to convert records into JSON text for B2
import joblib                    # to save the trained models to disk
import requests                  # to send an HTTP POST request to B2's server
import numpy as np               # numerical arrays (gaze, head movement samples)
import pandas as pd              # tables (dataset, results)
from sklearn.model_selection import train_test_split, cross_val_score   # 80/20 split + cross-validation
from sklearn.base import clone                                # copies a model for cross-validation
from sklearn.linear_model import LogisticRegression           # baseline model 1
from sklearn.ensemble import RandomForestClassifier           # baseline model 2
from sklearn.preprocessing import StandardScaler              # scales features for logistic regression
from sklearn.pipeline import make_pipeline                    # chains scaler + model
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, confusion_matrix)      # evaluation metrics
from xgboost import XGBClassifier                             # MAIN model (XGBoost)


rng = np.random.default_rng(42)  # fixed seed -> same random data every run (repeatable results)
HZ, SECONDS = 10, 10             # 10 samples per second, 10-second window
WIN = HZ * SECONDS               # = 100 samples per 10-second window

NORMAL = "Normal"
# The 7 abnormal behaviour types required by the assignment
ABNORMAL_TYPES = ["SuddenGazeDeviation", "RepeatedGazeDeviation", "LongFixation",
                  "AbnormalBlink", "SuddenHeadMovement", "RepeatedEmergencySelection",
                  "NoResponse"]


# =====================================================================================
# SECTION 2: B1.1 DATASET CREATION
# We have no real patient data, so we SIMULATE it.
# Idea: start from normal behaviour, then change it to create each abnormal type.
# =====================================================================================
def make_user_profile():
    """Every person has their own 'normal' (people differ), which makes the data more realistic."""
    return dict(gaze=rng.normal(4, 0.8), head=rng.normal(1.0, 0.25),
                blink=rng.normal(3.5, 0.8), fix=rng.normal(0.35, 0.05))


def generate_window(kind, user=None):
    """Simulate the raw behaviour data of ONE 10-second window for the given behaviour type."""
    u = user or dict(gaze=4, head=1.0, blink=3.5, fix=0.35)

    # ---- Normal baseline (used for every window first), based on this person's own normal ----
    gaze = np.abs(rng.normal(u["gaze"], 1.5, WIN))       # gaze deviation (degrees) at each of 100 samples
    head = np.abs(rng.normal(u["head"], 0.5, WIN))       # head movement at each of 100 samples
    fix = list(np.clip(rng.normal(u["fix"], 0.10, rng.integers(8, 15)), 0.1, None))  # fixation durations (sec)
    blinks = int(max(0, round(rng.normal(u["blink"], 1.2))))   # blinks in 10 seconds (varies a little)
    emergency = int(rng.random() < 0.05)         # 5% chance of an accidental button press

    # ---- Real normal behaviour is not perfectly clean: sometimes a harmless glitch happens ----
    if kind == NORMAL and rng.random() < 0.15:
        glitch = rng.integers(0, 3)
        s = rng.integers(0, WIN - 10)
        if glitch == 0:   gaze[s:s + rng.integers(3, 7)] = np.abs(rng.normal(10, 3))    # looks away briefly
        elif glitch == 1: head[s:s + 3] = np.abs(rng.normal(6, 2))                      # quick head turn
        else:             fix.append(rng.uniform(1.2, 2.5))                             # a longer look

    # ---- Modify the baseline to create each abnormal type (milder than before, so they can overlap normal) ----
    if kind == "SuddenGazeDeviation":            # eyes suddenly look far away for a few seconds
        s = rng.integers(0, WIN - 12)
        gaze[s:s + rng.integers(3, 10)] = np.abs(rng.normal(14, 5))
    elif kind == "RepeatedGazeDeviation":        # eyes look away several times in the window
        for _ in range(rng.integers(2, 5)):
            s = rng.integers(0, WIN - 8)
            gaze[s:s + 4] = np.abs(rng.normal(12, 4, 4))
    elif kind == "LongFixation":                 # staring at one point for a while
        fix = [max(1.5, rng.normal(3, 1)), 0.4]
        gaze = np.abs(rng.normal(2.0, 0.8, WIN))
    elif kind == "AbnormalBlink":                # either almost no blinking, or far too much
        blinks = int(rng.integers(0, 2)) if rng.random() < 0.5 else int(rng.integers(9, 17))
    elif kind == "SuddenHeadMovement":           # sudden strong head movement
        s = rng.integers(0, WIN - 10)
        head[s:s + rng.integers(3, 9)] = np.abs(rng.normal(8, 3))
    elif kind == "RepeatedEmergencySelection":   # user presses the emergency button several times
        emergency = int(rng.integers(2, 6))
    elif kind == "NoResponse":                   # very little movement, one very long fixation
        gaze = np.abs(rng.normal(1.0, 0.5, WIN))
        head = np.abs(rng.normal(0.3, 0.15, WIN))
        fix = [max(5.0, rng.normal(7, 1.5))]
        blinks = int(rng.integers(0, 3))

    return dict(gaze=gaze, head=head, fix=np.array(fix), blinks=blinks, emergency=emergency)


# =====================================================================================
# SECTION 3: B1.2 10-SECOND WINDOW PROCESSING / FEATURE EXTRACTION
# The model does not read 100 raw samples. We summarise each window into 8 numbers.
# This SAME function is used for training and for live prediction.
# =====================================================================================
def extract_features(w):
    """Continuous behaviour data -> 10-second window -> feature vector (8 numbers)."""
    return {
        "Mean_Gaze_Deviation": w["gaze"].mean(),           # average gaze deviation
        "Max_Gaze_Deviation": w["gaze"].max(),             # biggest gaze deviation
        "Blink_Rate": w["blinks"],                         # blinks per 10 seconds
        "Avg_Fixation_Duration": w["fix"].mean(),          # average fixation time
        "Max_Fixation_Duration": w["fix"].max(),           # longest fixation
        "Head_Movement": w["head"].max(),                  # strongest head movement
        "Gaze_Stability": 1.0 / (1.0 + w["gaze"].std()),   # 1 = very steady gaze, near 0 = unstable
        "Emergency_Button": w["emergency"],                # number of emergency presses
    }


def time_window(idx, start="14:35:00"):
    """Turns window number idx into a label like '14:35:10-14:35:20'."""
    h, m, s = map(int, start.split(":"))
    t0 = h * 3600 + m * 60 + s + idx * 10
    f = lambda t: f"{t // 3600:02d}:{(t // 60) % 60:02d}:{t % 60:02d}"
    return f"{f(t0)}-{f(t0 + 10)}"


def build_dataset(n_users=40, windows_per_user=30, p_abnormal=0.4):
    """Builds the full dataset: 40 users x 30 windows = 1200 rows, about 40% abnormal."""
    rows = []
    for u in range(1, n_users + 1):
        profile = make_user_profile()                                # this person's own normal
        for k in range(windows_per_user):
            abn = rng.random() < p_abnormal                          # decide normal or abnormal
            kind = rng.choice(ABNORMAL_TYPES) if abn else NORMAL     # pick the behaviour type
            row = {"User_ID": f"USER{u:03d}", "Time_Window": time_window(k)}
            row.update(extract_features(generate_window(kind, profile)))      # raw window -> 8 features
            row["Behaviour_Type"] = kind                 # for analysis only, NOT a model input
            row["Behaviour_Class"] = "Abnormal" if abn else "Normal" # the label the model learns
            rows.append(row)
    return pd.DataFrame(rows)


# =====================================================================================
# SECTION 4: B1.4 SEVERITY CLASSIFICATION (rule based, not machine learning)
# Runs only AFTER the model says ABNORMAL. Decides how serious it is.
# =====================================================================================
def count_indicators(r):
    """Counts how many danger signs are present in the window (0 to 5)."""
    return sum([
        r["Max_Gaze_Deviation"] > 10,                        # large gaze deviation
        r["Max_Fixation_Duration"] > 1.5,                    # long fixation
        r["Blink_Rate"] <= 1 or r["Blink_Rate"] > 8,         # abnormal blinking
        r["Head_Movement"] > 6,                              # sudden head movement
        r["Gaze_Stability"] < 0.25,                          # unstable gaze
    ])


def severity(r, prev_abnormal_windows):
    """prev_abnormal_windows = how many abnormal windows this user had just before this one."""
    ind = count_indicators(r)
    if (ind >= 2 and r["Emergency_Button"] >= 1) or r["Emergency_Button"] >= 3:
        return "HIGH"        # several danger signs + emergency press, or many presses
    if prev_abnormal_windows >= 1 or ind >= 2:
        return "MEDIUM"      # repeated abnormality, or several danger signs
    return "LOW"             # mild, one-off abnormality


# =====================================================================================
# SECTION 5: B1.3 MODEL EVALUATION HELPER
# Prints the metrics required by the assignment for any model.
# =====================================================================================
def evaluate(name, y_true, y_pred):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    print(f"\n=== {name} ===")
    print(f"Accuracy : {accuracy_score(y_true, y_pred):.4f}")
    print(f"Precision: {precision_score(y_true, y_pred):.4f}")
    print(f"Recall   : {recall_score(y_true, y_pred):.4f}")     # how many real emergencies we caught
    print(f"F1-score : {f1_score(y_true, y_pred):.4f}")
    print(f"FPR      : {fp / (fp + tn):.4f}")                   # false alarm rate
    print(f"FNR      : {fn / (fn + tp):.4f}")                   # missed emergency rate (most dangerous)
    print("Confusion matrix (rows=actual, cols=predicted)")
    print(pd.DataFrame([[tn, fp], [fn, tp]],
                       index=["Actual Normal", "Actual Abnormal"],
                       columns=["Pred Normal", "Pred Abnormal"]))


# =====================================================================================
# SECTION 6: INTEGRATION WITH GROUP B2  (B1 -> B2 hand-off)
# B1 only DETECTS. It does not confirm emergencies or notify caregivers.
# For every 10-second window, B1 builds one record and sends it to B2's server.
# B2 then does: confirmation -> state manager -> SMS -> dashboard -> event log.
# =====================================================================================
FEATURES = ["Mean_Gaze_Deviation", "Max_Gaze_Deviation", "Blink_Rate",
            "Avg_Fixation_Duration", "Max_Fixation_Duration", "Head_Movement",
            "Gaze_Stability", "Emergency_Button"]

# ---- Settings you / your partner may change ------------------------------------
B2_URL = None            # <-- paste the URL your partner gives you, e.g. "http://192.168.1.10:5000/api/b1"

# ---- Camera team's URL (B1 polls it with GET) -----------------------------------
CAMERA_URL = "https://deforest-chummy-sage.ngrok-free.dev/latest"   # changes if they restart ngrok
CAMERA_HEADERS = {"ngrok-skip-browser-warning": "true"}             # stops ngrok returning an HTML warning page
POLL_SECONDS = 3                                                    # how often to ask for new windows
LIVE_LOG = "live_log.csv"                                            # every live window + prediction is saved here
THRESHOLD = 0.5          # model probability at or above this value -> window is called ABNORMAL
REQUEST_TIMEOUT = 5      # seconds to wait for B2's server before giving up
BACKUP_FILE = "b1_output.jsonl"   # every record is also saved here (audit / fallback)


class B1Detector:
    """
    Group B1 output interface. Group B2 only needs this record per 10-second window:

        {"User_ID": "USER001", "Time_Window": "14:35:10-14:35:20",
         "Prediction": "ABNORMAL",   # or "NORMAL"
         "Confidence": 0.94,         # 0-1, confidence in the predicted class
         "Severity": "HIGH"}         # LOW / MEDIUM / HIGH for ABNORMAL, "NONE" for NORMAL

    Windows must be fed in time order for each user ("repeated abnormality" uses history).
    """

    def __init__(self, model, ranges=None):
        self.model = model               # the trained XGBoost model
        self.ranges = ranges or {}       # feature -> (low, high): normal range seen in our dataset
        self.prev_abnormal = {}          # remembers, per user, how many abnormal windows in a row

    def predict_window(self, user_id, time_window, features):
        # 1) Model gives the probability that this window is abnormal
        x = pd.DataFrame([features])[FEATURES]
        p_abn = float(self.model.predict_proba(x)[0, 1])

        # 2) Apply OUR threshold to decide NORMAL or ABNORMAL
        abnormal = p_abn >= THRESHOLD

        # 3) Severity only for abnormal windows; update the per-user history
        if abnormal:
            sev = severity(features, self.prev_abnormal.get(user_id, 0))
            self.prev_abnormal[user_id] = self.prev_abnormal.get(user_id, 0) + 1
        else:
            sev = "NONE"
            self.prev_abnormal[user_id] = 0      # a normal window resets the streak

        # 4) This dictionary IS the message B2 receives
        return {"User_ID": user_id,
                "Time_Window": time_window,
                "Prediction": "ABNORMAL" if abnormal else "NORMAL",
                "Confidence": round(p_abn if abnormal else 1 - p_abn, 2),  # confidence in the chosen class
                "Severity": sev}


def send_to_b2(record):
    """
    >>> THIS IS WHERE B1 CONNECTS TO B2 <<<
    Wraps the result as a JSON body and POSTs it to the URL on the partner's server.
    Every record is also appended to BACKUP_FILE, so nothing is lost if the server is down.
    Returns True if the server accepted it, False otherwise.
    """
    # Always keep a local copy first (audit trail + fallback)
    with open(BACKUP_FILE, "a") as f:
        f.write(json.dumps(record) + "\n")

    # If the partner has not given us the URL yet, only the local copy is saved
    if not B2_URL:
        print("[B1] B2_URL not set yet - saved to file only.")
        return False
    try:
        r = requests.post(B2_URL, json=record, timeout=REQUEST_TIMEOUT)   # sends the JSON body to B2
        r.raise_for_status()                                              # error if B2 did not answer 200
        return True
    except requests.RequestException as e:
        # Server down / wrong URL: do not crash, the record is already saved in BACKUP_FILE
        print(f"[B1] Could not reach B2 server ({e}) - record kept in {BACKUP_FILE}")
        return False


def log_live(msg, feats, rec, outside):
    """Saves one row per live window: the 8 input values, B1's answer and the out-of-range values."""
    row = {"Logged_At": time.strftime("%Y-%m-%d %H:%M:%S"), "User_ID": rec["User_ID"], "Time_Window": rec["Time_Window"]}
    row.update(feats)
    row.update({"Prediction": rec["Prediction"], "Confidence": rec["Confidence"], "Severity": rec["Severity"],
                "Outside_Normal_Range": ";".join(outside)})
    pd.DataFrame([row]).to_csv(LIVE_LOG, mode="a", header=not os.path.exists(LIVE_LOG), index=False)


def poll_camera(detector, url):
    """
    >>> THIS IS WHERE B1 CONNECTS TO THE CAMERA TEAM <<<
    Every POLL_SECONDS: GET the camera team's URL. It returns a JSON list with the latest
    completed 10-second window of each patient ([] if none yet). The same window stays in the
    list until the next one is ready, so windows already processed (same User_ID + Time_Window)
    are skipped. Each new window -> prediction + severity -> sent to B2.
    """
    seen = set()                                       # (User_ID, Time_Window) already processed
    print(f"[B1] Polling {url} every {POLL_SECONDS}s  (Ctrl+C to stop)")
    while True:
        try:
            r = requests.get(url, headers=CAMERA_HEADERS, timeout=REQUEST_TIMEOUT)
            r.raise_for_status()
            msgs = r.json()                            # fails if the server sent HTML instead of JSON
            if isinstance(msgs, dict):                 # accept a single object as well as a list
                msgs = [msgs]
            for msg in sorted(msgs, key=lambda m: str(m.get("Time_Window", ""))):   # time order
                key = (msg.get("User_ID"), msg.get("Time_Window"))
                if key in seen:
                    continue                           # already processed this window
                seen.add(key)
                try:
                    feats = {k: float(msg[k]) for k in FEATURES}     # the 8 numeric inputs
                    rec = detector.predict_window(msg["User_ID"], msg["Time_Window"], feats)
                except (KeyError, ValueError, TypeError) as e:
                    print(f"[B1] Skipped bad window {key}: {e!r}")
                    continue
                # Which input values lie outside the normal range of our dataset? (helps find the cause of a false alarm)
                outside = [f for f, (lo, hi) in detector.ranges.items() if not (lo <= feats[f] <= hi)]
                log_live(msg, feats, rec, outside)
                print(f"[B1] {rec['User_ID']} {rec['Time_Window']} -> {rec['Prediction']} "
                      f"(confidence {rec['Confidence']}, severity {rec['Severity']})"
                      + (f"  outside normal range: {', '.join(outside)}" if outside else ""))
                send_to_b2(rec)                        # hand-off to B2
        except (requests.RequestException, ValueError) as e:
            print(f"[B1] Camera poll problem (will retry): {e}")
        time.sleep(POLL_SECONDS)


def run_demo_stream(detector):
    """
    DEMO of the live flow: one user goes from normal behaviour into an emergency.
    Each window is predicted and immediately sent to B2, exactly as in the real system.
    """
    open(BACKUP_FILE, "w").close()       # start with an empty backup file
    scenario = [NORMAL, NORMAL, NORMAL, "NoResponse", "NoResponse",
                "RepeatedEmergencySelection", "RepeatedEmergencySelection", NORMAL]
    rows = []
    for k, kind in enumerate(scenario):
        feats = extract_features(generate_window(kind))             # 10-sec window -> features
        rec = detector.predict_window("USER001", time_window(k), feats)  # prediction + severity
        send_to_b2(rec)                                             # hand-off to B2
        rows.append(rec)
    out = pd.DataFrame(rows)
    out.to_csv("b1_output.csv", index=False)
    print("\n=== Live stream demo: records sent to B2 ===")
    print(out.to_string(index=False))
    print("\nSaved: b1_output.jsonl (one JSON per window) and b1_output.csv")


# =====================================================================================
# SECTION 7: MAIN - builds data, trains and compares models, then runs the B2 demo
# =====================================================================================
def main():
    # --- B1.1 / B1.2: create the dataset and save it
    df = build_dataset()
    df.to_csv("dataset.csv", index=False)
    print(f"Dataset: {len(df)} windows saved to dataset.csv")
    print(df["Behaviour_Class"].value_counts().to_string())

    # --- Split into inputs (X = 8 features) and answer (y: 1 = abnormal, 0 = normal)
    X = df[FEATURES]
    y = (df["Behaviour_Class"] == "Abnormal").astype(int)
    # 80% for training, 20% for testing on data the model has never seen
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

    # --- B1.3: train XGBoost and the two baseline models
    models = {
        "Logistic_Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)),
        "Random_Forest": RandomForestClassifier(n_estimators=100, random_state=42,
                                                max_depth=5,          # restrict depth to prevent memorising
                                                min_samples_leaf=4),
        "XGBoost": XGBClassifier(n_estimators=100, max_depth=3,
                                 learning_rate=0.05,                  # slower learning
                                 subsample=0.8,                       # each tree sees 80% of rows
                                 colsample_bytree=0.8,                # each tree sees 80% of features
                                 eval_metric="logloss", random_state=42),
    }
    for name, m in models.items():
        m.fit(X_tr, y_tr)                                # learn from the training data
        evaluate(name, y_te, m.predict(X_te))            # test on unseen data and print metrics
        joblib.dump(m, f"{name}.joblib")                 # save the trained model to disk
        print(f"Saved {name} model to {name}.joblib")

    xgb = models["XGBoost"]

    # --- Overfitting check: a big gap between train and test accuracy would mean overfitting
    cv = cross_val_score(clone(xgb), X, y, cv=5)         # 5-fold cross-validation on all the data
    print("\nOverfitting check (XGBoost):")
    print(f"Train accuracy: {xgb.score(X_tr, y_tr):.4f}   Test accuracy: {xgb.score(X_te, y_te):.4f}")
    print(f"5-fold cross-validation accuracy: {cv.mean():.4f} (+/- {cv.std():.4f})")

    # --- Which features did XGBoost rely on most?
    print("\nXGBoost feature importance:")
    print(pd.Series(xgb.feature_importances_, index=FEATURES)
          .sort_values(ascending=False).round(3).to_string())

    # --- Run: poll the camera team's URL (or the simulated demo if no URL is set)
    normal = df[df["Behaviour_Class"] == "Normal"][FEATURES]
    ranges = {f: (float(normal[f].quantile(0.01)), float(normal[f].quantile(0.99))) for f in FEATURES}
    detector = B1Detector(xgb, ranges)
    arg = sys.argv[1] if len(sys.argv) > 1 else None
    if arg == "demo":
        url = None                                       # demo mode: simulated patient, no camera needed
    else:
        url = arg or CAMERA_URL                          # a URL typed on the command line, else the one in the settings
    try:
        if url:
            poll_camera(detector, url)
        else:
            run_demo_stream(detector)
    except KeyboardInterrupt:
        print("\n[B1] Stopped.")


if __name__ == "__main__":
    main()
