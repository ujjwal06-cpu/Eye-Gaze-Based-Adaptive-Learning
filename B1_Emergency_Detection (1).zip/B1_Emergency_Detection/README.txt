GROUP B1 - AI-BASED 10-SECOND EMERGENCY BEHAVIOUR DETECTION
============================================================

FILES IN THIS FOLDER
  b1_emergency_detection.py   The B1 program (training, prediction, severity, polling, sending to B2)
  dataset.csv                 The synthetic dataset B1 is trained on (1200 windows)
  B1_Data_Requirements.pdf    Input format given to the camera team
  requirements.txt            Python libraries needed

SETUP (first time only)
  python -m venv venv
  venv\Scripts\activate            (Mac/Linux: source venv/bin/activate)
  pip install -r requirements.txt

RUN
  python b1_emergency_detection.py             polls the camera team's URL
  python b1_emergency_detection.py <url>       polls a different URL (e.g. after ngrok restarts)
  python b1_emergency_detection.py demo        no camera needed: runs a simulated patient (normal -> emergency -> normal)

WHAT HAPPENS WHEN YOU RUN IT
  1. Builds the dataset (dataset.csv) and trains Logistic Regression, Random Forest and XGBoost.
  2. Prints accuracy, precision, recall, F1, FPR, FNR, confusion matrices and an overfitting check.
  3. Saves the trained models (*.joblib).
  4. Polls the camera URL every 3 seconds; each new 10-second window gets a
     prediction (NORMAL / ABNORMAL), confidence and severity (LOW / MEDIUM / HIGH / NONE).
  5. Sends each result to B2 (once B2_URL is set) and saves it to b1_output.jsonl.
  6. Saves every live window and its prediction to live_log.csv, with a column showing which
     values are outside the normal range of the dataset (to tell measurement problems from model problems).

SETTINGS (top of the .py file, Section 6)
  CAMERA_URL      camera team's URL (changes if ngrok restarts)
  B2_URL          Group B2's endpoint (None until the partner shares it)
  THRESHOLD       0.5 - probability at or above this means ABNORMAL (lower it to catch more emergencies)
  POLL_SECONDS    3
  Severity rules  count_indicators() / severity() in Section 4

GENERATED WHEN YOU RUN IT (not included)
  Logistic_Regression.joblib, Random_Forest.joblib, XGBoost.joblib, b1_output.jsonl, live_log.csv

IMPORTANT
  The dataset is SYNTHETIC. Scores show the pipeline works; they do not prove performance on real patients.
  Retrain on real labelled windows when available.
