from django.apps import AppConfig


class EyeGazeAppConfig(AppConfig):
    name = 'Eye_Gaze_App'
