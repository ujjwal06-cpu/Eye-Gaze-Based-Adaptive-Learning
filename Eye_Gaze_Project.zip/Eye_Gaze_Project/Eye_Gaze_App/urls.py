from django.urls import path
from . import views

# Set app_name for URL namespacing
app_name = "Eye_Gaze_App"

urlpatterns = [
    # Static Route: /contact/
    path("", views.entry_route, name="Home_page"),

    # Route with dynamic path converter: /user/42/
    path("login_page/", views.login_func, name="login_func"),

    # API Route: /api/users/create/
    path("web_dashboard/", views.prepare_dashboard, name="process_dashboard"),
    path("logout_form/",views.func_logout,name="func_logout"),
    path("AI_API/",views.Emergency_confirm,name="confirm_emergency"),
    path("receive_response/",views.check_for_response_to_sms_alert,name="response_sms")
]
