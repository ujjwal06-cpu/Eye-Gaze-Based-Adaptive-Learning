from django.contrib import admin
from django.db import models
from . import models as md
class Hospital_officials_admin(admin.ModelAdmin):
    search_fields=["emp_id"]
def register_the_model():
    admin.site.register(md.Hospital_officials,Hospital_officials_admin)
register_the_model()
# Register your models here.
