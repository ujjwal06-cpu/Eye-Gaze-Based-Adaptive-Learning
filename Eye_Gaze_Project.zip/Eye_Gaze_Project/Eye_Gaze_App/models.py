from django.db import models
from django.db.models import Q
class Patient(models.Model):
    Patient_id=models.CharField(max_length=7,primary_key=True)
    name=models.CharField(max_length=50)
    phone_num=models.CharField(max_length=10,unique=True)
    window_count=models.IntegerField(default=0)
    class Meta:
        constraints=[models.CheckConstraint(condition=Q(phone_num__lte='9999999999'),name='h1'),
        models.CheckConstraint(condition=Q(phone_num__gte='1000000000'),name='h2'),
        models.CheckConstraint(condition=Q(window_count__lte=3),name='h3'),
        models.CheckConstraint(condition=Q(window_count__gte=0),name='h4')
        ]
class Event_log(models.Model):
                #from django.db import models
    times=models.DateTimeField(auto_now=True,primary_key=True)
    prediction=models.CharField(max_length=8)
    Conf_Score=models.IntegerField()
    Alert_Status=models.BooleanField()
    Response_Status=models.BooleanField()
    Severity_stats=models.CharField(max_length=10)
    patient_id=models.ForeignKey(Patient,on_delete=models.CASCADE)
class Hospital_officials(models.Model):
    emp_id=models.CharField(max_length=10,primary_key=True)
    emp_name=models.CharField(max_length=50)
#create_models()
# Create your models here.
