from Eye_Gaze_App.models import Patient,
from django.core.management.base import BaseCommand
from .patient_data import patients
class Command(BaseCommand):
    help = "Populate database with initial articles"

    def handle(self, *args, **options):

        patient_data=[]
        count=2
        """
        while(count<=40):
            strs=''
            if(count<10):
                strs+='0'
            _id="USER0"+strs+str(count)
            patient_obj=Patient(Patient_id=_id,name=patients[count-2]['name'],phone_num=patients[count-2]['phone_num'],window_count=0)
            patient_data.append(patient_obj)
            count+=1
        Patient.objects.bulk_create(patient_data)
        """
        #patients=Patient.objects.all()
        #print(len(patients))
        """
        patient_all=Patient.objects.all()
        for patient in patient_all:
            print(patient.Patient_id,patient.name)
        """
        Event_log.object.delete(prediction__exact="Emergency")
        self.stdout.write(self.style.SUCCESS("Successfully inserted data!"))