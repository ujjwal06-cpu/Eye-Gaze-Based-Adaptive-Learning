
from django.shortcuts import render
from django.http import HttpResponse
from django.utils import timezone
from sms import send_sms
from . import models as md
from . import threshold_limits as th_l
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import csrf_exempt
import json
#-------------first page displayed to the user-------------
def entry_route(request):
    stat=0
    context={
        "stat":stat
    }
    return render(request,"Eye_Gaze_App/login_page.html",context,status=200)


#----------to render login page---------------------
def login_func(request):
    usernames=request.POST.get("username")
    passwords=request.POST.get("password")
    user_field=authenticate(request,username=usernames,password=passwords)
    if user_field is not None:
        login(request,user_field)
    else:
        stat=1
        context={
            "stat":stat
        }
        return render(request,"Eye_Gaze_App/login_page.html",context,status=200)
    return redirect("Eye_Gaze_App:process_dashboard")


#--------to render dashboard---------------
def prepare_dashboard(request):
    #---- querying for event_log--------
    log_data=md.Event_log.objects.filter(prediction__exact="Emergency")

    #------extracting final patient data---------------
    final_data=[]
    filter_patient_data={}


    #---------filtering the log list patient wise-----------

    #function to format the final_data to be added in the list
    def add_data(_id,log_data):
        list_val=[]
        list_val.append(_id)
        list_val.append(str(log_data.times))
        list_val.append(log_data.prediction)
        list_val.append(log_data.Conf_Score)
        list_val.append(log_data.Alert_Status)
        list_val.append(log_data.Response_Status)
        list_val.append(log_data.Severity_stats)
        return list_val



    for log in log_data:
        #----extracting patient details----------
        if len(filter_patient_data)==0 or log.patient_id.Patient_id not in filter_patient_data.keys():
            filter_patient_data.update({log.patient_id.Patient_id:[log]})
        else:
            filter_patient_data[log.patient_id.Patient_id].append(log)



    #----------finding the latest log data for each patient id available and adding it to the final list------------
    patient_id_list=filter_patient_data.keys()
    #print(filter_patient_data,"\n\n\n\n\n")
    for _id in patient_id_list:
        maxs=filter_patient_data[_id][0].times
        #print(maxs,"\n\n\n\n")
        index=0
        log_list=filter_patient_data[_id]
        for i in range(len(log_list)):
            if log_list[i].times>maxs:
                maxs=log_list[i].times
                index=i
        if(len(log_list)>0):
            final_data.append(add_data(_id,log_list[index]))
    print((final_data))
    context={
        "patient_list":final_data
    }
    if request.headers.get('HX-Request'):
        return render(request,"Eye_Gaze_App/dashboard/patient_snippets/emergency.html",context,status=200)
    return render(request,"Eye_Gaze_App/dashboard/main_dashboard.html",context,status=200)


#------------logout form----------------
def func_logout(request):
    if request.user.is_authenticated:
        logout(request)
    return redirect("Eye_Gaze_App:Home_page")

#----------------Emergency confirmation----------

@csrf_exempt
def Emergency_confirm(request):
    data=json.loads(request.body.decode('utf-8'))
    _id=data["User_ID"]
    Time_Window=data["Time_Window"]
    Prediction=data["Prediction"]
    Conf_score=data["Confidence"]
    Severity=data["Severity"]
    stat=0
    #print(request.POST)
    if(_id == None):
        #print("empty body")
        return HttpResponse("Sorry but message not received successfully")
    print("User_ID",_id,"\n\n\n\n\n\n\n\n")
    Patient_data=md.Patient.objects.get(Patient_id=_id)
    alert_stat=False
    if Prediction=="ABNORMAL":
        if(Conf_score>th_l.threshold_limit_val_Emergency_confirm):
            #Patient_data=md.Patient.objects.filter(Patient_id=_id)
            alert_stat=True
            Prediction="Emergency"
            window_count=Patient_data.window_count 
            window_count=window_count+1
            md.Patient.objects.filter(Patient_id=_id).update(window_count=window_count)
            if(not window_count<3):
                md.Patient.objects.filter(Patient_id=_id).update(window_count=0)
                stat=1
        else:

            
            prediction="NORNAL"
    response_stat=False
    """
    times
    prediction
    Conf_Score
    Alert_Status
    Response_Status
    Severity_stats    
    patient_id
    """
    log_inst=md.Event_log(prediction=Prediction,Conf_Score=Conf_score,Alert_Status=alert_stat,Response_Status=response_stat,Severity_stats=Severity,patient_id=Patient_data)
    phone_patient=log_inst.patient_id.phone_num
    log_inst.save()   

    #------sending alert if emergency confirmed----------
    if(stat):
        #-------send alert-------
        phone_num='+91'+phone_patient
        send_sms(
            body='Medical Emergency ,Patient is under risk ',
        #-----------formatting the phone number of patient-------------
            #phone_number='+91'+phone_patient,
            recipients=[phone_num]
        )
        #-----------------------alert sent successfully--------------
    return HttpResponse('Event_log added successfully',status=200)


#--------------receiving the SMS response-------------

def check_for_response_to_sms_alert(request):
    phone_num=request.POST.get('phone_number')
    log_data=md.Event_log.objects.filter(patient_id__phone_num=phone_num,prediction__exact='Emergency')

    max=log_data[0].times
    latest_log=log_data[0]
    for log in log_data:
        if max<log.times:
            latest_log=log
            max=log.times
    
    patient_id=latest_log.patient_id
    prediction=latest_log.prediction
    Conf_Score=latest_log.Conf_Score
    Alert_Status=latest_log.Alert_Status
    Response_Status=True
    Severity_stats=latest_log.Severity_stats
    _ids=patient_id.Patient_id
    Patient_data=md.Patient.objects.get(Patient_id=_ids)
    md.Event_log.objects.create(prediction=prediction,Conf_Score=Conf_Score,Alert_Status=Alert_Status,Response_Status=Response_Status,Severity_stats=Severity_stats,patient_id=Patient_data)
    md.Patient.objects.filter(Patient_id=_ids).update(window_count=0)
    
    return HttpReponse("Message received Successfully",status=200)
